[
{"result": "https://telegra.ph/file/5cf2bce4de1d1eb785e9e.jpg"},
{"result": "https://telegra.ph/file/1f4fd098fcf710081ecdf.jpg"},
{"result": "https://telegra.ph/file/c3a8cf19f86170357299b.jpg"},
{"result": "https://telegra.ph/file/940fa30d104005a1299e3.jpg"},
{"result": "https://telegra.ph/file/7482f8a2334de439b8b5d.jpg"},
{"result": "https://telegra.ph/file/661b8a69243d9bd4bee48.jpg"},
{"result": "https://telegra.ph/file/7f69357b1cdf01c8f58d9.jpg"},
{"result": "https://telegra.ph/file/690194b26f8f4c27bc6ad.jpg"},
{"result": "https://telegra.ph/file/52d87fd81e8f20c4ab848.jpg"},
{"result": "https://telegra.ph/file/d445cfa7f46528498ab9c.jpg"},
{"result": "https://telegra.ph/file/85ca52c3c01bd22448de8.jpg"},
{"result": "https://telegra.ph/file/7d8a9a7e2048a30f34f23.jpg"}
]