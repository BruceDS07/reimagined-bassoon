[
{"result": "https://telegra.ph/file/a7ec2e853f299c7e2edd0.jpg"},
{"result": "https://telegra.ph/file/fadc6144fa61b78dd573c.jpg"},
{"result": "https://telegra.ph/file/2b37be29b96bd0676b7f9.jpg"},
{"result": "https://telegra.ph/file/4ff33214c5adf3352189e.jpg"},
{"result": "https://telegra.ph/file/8a4f85a01ccfa4a1f2b76.jpg"}
]